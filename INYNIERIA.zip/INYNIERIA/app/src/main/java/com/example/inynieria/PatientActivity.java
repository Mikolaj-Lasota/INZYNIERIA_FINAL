package com.example.inynieria;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import android.view.View;

import android.util.Log;
import android.database.Cursor;
import android.widget.Switch;

public class PatientActivity extends AppCompatActivity implements  View.OnClickListener {

    public TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient);

        txt = (TextView)findViewById(R.id.textViewLOGGED);
        txt.setText(people.login);
    }

    public void onClick(View v){
        switch(v.getId())
        {
            case R.id.buttonWizyty:
                Intent switchActivityIntent1 = new Intent(this, WizytaActivity.class);
                startActivity(switchActivityIntent1);
                break;

            case R.id.buttonRecepty:
                Intent switchActivityIntent2 = new Intent(this, ReceptaActivity.class);
                startActivity(switchActivityIntent2);
                break;

            case R.id.buttonRozliczenia:
                Intent switchActivityIntent3 = new Intent(this, RozliczenieActivity.class);
                startActivity(switchActivityIntent3);
                break;


            case R.id.buttonKomunikat2:
                Intent switchActivityIntent4 = new Intent(this, activityKomunikatPatient.class);
                startActivity(switchActivityIntent4);
                break;

            case R.id.buttonWylogujPatient:

                people.personel_or_patient = null;
                people.name = null;
                people.surname = null;
                people.login = null;
                people.personId = null;

                Intent switchActivityIntent5 = new Intent(this, MainActivity.class);
                startActivity(switchActivityIntent5);
                break;

        }
    }

}