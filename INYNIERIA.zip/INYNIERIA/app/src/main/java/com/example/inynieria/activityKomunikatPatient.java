package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class activityKomunikatPatient extends AppCompatActivity  implements  View.OnClickListener  {


    public Button btnBack;

    public TextView komunikat;

ZarzadzajDanymi dm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_komunikat_patient);


        btnBack = (Button) findViewById(R.id.buttonBackKomunikatPatient);
        komunikat = (TextView)  findViewById(R.id.textViewKomunikatPatient);

        komunikat.setMovementMethod(new ScrollingMovementMethod());

        komunikat.setText(dm.showKomunikat(people.personel_or_patient));
    }




    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.buttonBackKomunikatPatient:
                Intent switchActivityIntent = new Intent(this, PatientActivity.class);
                startActivity(switchActivityIntent);
                break;
        }
    }
}