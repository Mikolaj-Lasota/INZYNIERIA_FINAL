package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class activityWystawRecepte extends AppCompatActivity   implements  View.OnClickListener {



    public Button btnBack;
    public Button btnRecepta;
    public EditText lek;
    public EditText name;
    public EditText surname;

    ZarzadzajDanymi dm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wystaw_recepte);


        btnBack = (Button) findViewById(R.id.buttonBackWystawRecepty);
        btnRecepta = (Button)  findViewById(R.id.buttonInsertRecepta);

        lek = (EditText) findViewById(R.id.editTextTextReceptaLek);
        name = (EditText) findViewById(R.id.editTextTextReceptaImie);
        surname = (EditText) findViewById(R.id.editTextTextReceptaNazwisko);

    }



    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.buttonBackWystawRecepty:
                Intent switchActivityIntent = new Intent(this, PersonelActivity.class);
                startActivity(switchActivityIntent);
                break;

            case R.id.buttonInsertRecepta:
                dm.InsertRecepta(lek.getText().toString(),name.getText().toString(),surname.getText().toString());
                break;
        }
    }


}