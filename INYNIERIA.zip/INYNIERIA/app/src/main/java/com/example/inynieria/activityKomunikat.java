package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class activityKomunikat extends AppCompatActivity implements  View.OnClickListener {

    public Button btnBack;

    public TextView lista;

    ZarzadzajDanymi dm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_komunikat);


        btnBack = (Button) findViewById(R.id.buttonBackKomunikat);
        lista = (TextView)  findViewById(R.id.textViewKomunikat);

        lista.setMovementMethod(new ScrollingMovementMethod());

        lista.setText(dm.showKomunikat(people.personel_or_patient));
    }



    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.buttonBackKomunikat:
                Intent switchActivityIntent = new Intent(this, PersonelActivity.class);
                startActivity(switchActivityIntent);
                break;
        }
    }
}