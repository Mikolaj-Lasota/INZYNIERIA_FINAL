package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class activityWystawRozliczenie extends AppCompatActivity implements  View.OnClickListener  {




    public Button btnBack;
    public Button btnRozliczenie;
    public EditText cena;
    public EditText name;
    public EditText surname;

    ZarzadzajDanymi dm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wystaw_rozliczenie);



        btnBack = (Button) findViewById(R.id.buttonBackWystawRozliczenie);
        btnRozliczenie = (Button)  findViewById(R.id.buttonInsertRozliczenie);

        cena = (EditText) findViewById(R.id.editTextTextCena);
        name = (EditText) findViewById(R.id.editTextTextRozliczenieImie);
        surname = (EditText) findViewById(R.id.editTextTextRozliczenieNazwisko);

    }







    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.buttonBackWystawRozliczenie:
                Intent switchActivityIntent = new Intent(this, PersonelActivity.class);
                startActivity(switchActivityIntent);
                break;

            case R.id.buttonInsertRozliczenie:
                dm.InsertRozliczenia(Float.parseFloat(cena.getText().toString()),name.getText().toString(),surname.getText().toString());
                break;
        }
    }

}