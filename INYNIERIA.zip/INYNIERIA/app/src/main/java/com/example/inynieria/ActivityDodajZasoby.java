package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

public class ActivityDodajZasoby extends AppCompatActivity  implements  View.OnClickListener {


    public Button btnBack;
    public Button btnDodajZasoby;
    public EditText zasoby;


    ZarzadzajDanymi dm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_zasoby);


        btnBack = (Button) findViewById(R.id.buttonBackDodajZasoby);
        btnDodajZasoby = (Button)  findViewById(R.id.buttonInsertZasob);

        zasoby = (EditText) findViewById(R.id.editTextTextDodajZasob);
    }




    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.buttonBackDodajZasoby:
                Intent switchActivityIntent = new Intent(this, PersonelActivity.class);
                startActivity(switchActivityIntent);
                break;

            case R.id.buttonInsertZasob:

                dm.InsertZasob(zasoby.getText().toString());

                break;
        }
    }
}