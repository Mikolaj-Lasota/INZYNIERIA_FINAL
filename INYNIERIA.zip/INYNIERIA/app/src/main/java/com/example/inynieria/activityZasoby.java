package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class activityZasoby extends AppCompatActivity implements  View.OnClickListener {


    public Button btnBack;

    public TextView zasoby;

    ZarzadzajDanymi dm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zasoby);


        btnBack = (Button) findViewById(R.id.buttonBackZasob);
        zasoby = (TextView)  findViewById(R.id.textViewZasob);

        zasoby.setMovementMethod(new ScrollingMovementMethod());

        zasoby.setText(dm.showZasob());
    }



    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.buttonBackZasob:
                Intent switchActivityIntent = new Intent(this, PersonelActivity.class);
                startActivity(switchActivityIntent);
                break;
        }
    }
}