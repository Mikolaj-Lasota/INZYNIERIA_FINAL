package com.example.inynieria;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import android.view.View;

import android.util.Log;
import android.database.Cursor;
import android.widget.Switch;




public class MainActivity extends AppCompatActivity implements  View.OnClickListener {

public Button btn_login;
public Button btn_register;

public EditText edit_login;
public EditText edit_password;



public Button btn_show;


        ZarzadzajDanymi dm;

@Override
protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_login = (Button)findViewById(R.id.button_login);
        btn_register = (Button)findViewById(R.id.button_register);


        btn_show = (Button)findViewById(R.id.button_show);

        dm= new ZarzadzajDanymi(this);

        edit_login = (EditText) findViewById(R.id.editTextTextLogin);
        edit_password = (EditText) findViewById(R.id.editTextTextPassword);

        }

public void showData(Cursor c){
        while(c.moveToNext()){
        Log.i(c.getString(1),c.getString(2));
        }
        }


@Override
public void onClick(View v){
        switch(v.getId())
        {
                case R.id.button_register:
                Intent switchActivityIntent = new Intent(this, SecondActivity.class);
                startActivity(switchActivityIntent);

        break;

            case R.id.button_show:
                showData(dm.SelectAll());

            case R.id.button_login:
       boolean  check =  dm.CheckLogin(edit_login.getText().toString(),edit_password.getText().toString());





          if(check){
              if(people.personel_or_patient == "false")
              {
                  Intent switchActivityIntent1 = new Intent(this, PersonelActivity.class);
                  startActivity(switchActivityIntent1);

              }
           else
           {
                  Intent switchActivityIntent1 = new Intent(this, PatientActivity.class);
                  startActivity(switchActivityIntent1);
              }




        }




        }
        }
        }
