package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ReceptaActivity extends AppCompatActivity  implements  View.OnClickListener  {


    public Button btnBack;

    public TextView recepty;

    ZarzadzajDanymi dm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recepta);

        btnBack = (Button) findViewById(R.id.buttonBackRecepty);
        recepty = (TextView)  findViewById(R.id.textViewRecepta);

        recepty.setMovementMethod(new ScrollingMovementMethod());

        recepty.setText(dm.showRecepty(people.name,people.surname));

    }





    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.buttonBackWizyty:
                Intent switchActivityIntent = new Intent(this, PatientActivity.class);
                startActivity(switchActivityIntent);
                break;
        }
    }
}