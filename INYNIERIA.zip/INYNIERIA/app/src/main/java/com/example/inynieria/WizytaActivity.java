package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import android.view.View;

import android.util.Log;
import android.database.Cursor;
import android.widget.Switch;



public class WizytaActivity extends AppCompatActivity  implements  View.OnClickListener  {

    public Button btnBack;
    public Button btnWizyty;

    public EditText choroba;
    public EditText doktorName;
    public EditText doktorSurname;

    ZarzadzajDanymi dm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wizyta);

    btnBack = (Button) findViewById(R.id.buttonBackWizyty);
    btnWizyty = (Button)  findViewById(R.id.buttonInsertWizyty);

    choroba = (EditText) findViewById(R.id.editTextTextWizytaChoroba);
    doktorName = (EditText) findViewById(R.id.editTextTextWizytaDoktorImie);
    doktorSurname = (EditText) findViewById(R.id.editTextTextWizytaDoktorNazwisko);

        dm= new ZarzadzajDanymi(this);

    }


    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.buttonBackWizyty:
                Intent switchActivityIntent = new Intent(this, PatientActivity.class);
                startActivity(switchActivityIntent);
                break;

            case R.id.buttonInsertWizyty:
                dm.InsertWizyta(choroba.getText().toString(),doktorName.getText().toString(),doktorSurname.getText().toString());
                break;
        }
    }
}