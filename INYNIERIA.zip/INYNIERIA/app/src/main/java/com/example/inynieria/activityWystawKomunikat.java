package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;


public class activityWystawKomunikat extends AppCompatActivity implements  View.OnClickListener {




    public Button btnBack;
    public Button btnKomunikat;
    public EditText komunikat;
    public Switch personelPacjent;

    ZarzadzajDanymi dm;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wystaw_komunikat);


        personelPacjent = (Switch) findViewById(R.id.switchKomunikat);

        btnBack = (Button) findViewById(R.id.buttonBackWystawKomunikat);
        btnKomunikat = (Button)  findViewById(R.id.buttonInsertKomunikat);

        komunikat = (EditText) findViewById(R.id.editTextTextWyslijKomunikat);

    }









    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.buttonBackWystawKomunikat:
                Intent switchActivityIntent = new Intent(this, PersonelActivity.class);
                startActivity(switchActivityIntent);
                break;

            case R.id.buttonInsertKomunikat:
                String checked;
                if(personelPacjent.isChecked()){
                    checked = "personel";
                }
                else{
                    checked = "pacjent";
                }
                dm.InsertKomunikat(komunikat.getText().toString(),checked);
                break;
        }
    }
}