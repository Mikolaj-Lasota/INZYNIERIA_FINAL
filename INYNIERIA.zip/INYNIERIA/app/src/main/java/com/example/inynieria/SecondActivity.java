package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import android.view.View;

import android.util.Log;
import android.database.Cursor;
import android.widget.Switch;

public class SecondActivity extends AppCompatActivity implements  View.OnClickListener {


    public Button btn_register;

    public EditText edit_login;
    public EditText edit_password;

    public EditText edit_name;
    public EditText edit_surname;

public Switch peronel_patient;
    ZarzadzajDanymi dm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        btn_register = (Button)findViewById(R.id.button_registerFinal);


        dm= new ZarzadzajDanymi(this);


        edit_name = (EditText) findViewById(R.id.editTextTextRegisterName) ;
        edit_surname = (EditText) findViewById(R.id.editTextTextRegisterSurname) ;
        edit_login = (EditText) findViewById(R.id.editTextTextLogin);
        edit_password = (EditText) findViewById(R.id.editTextTextPassword);
        peronel_patient = (Switch) findViewById(R.id.switch1);


    }

    public void showData(Cursor c){
        while(c.moveToNext()){
            Log.i(c.getString(1),c.getString(2));
        }
    }
    @Override
    public void onClick(View v){
        switch(v.getId())
        {
            case R.id.button_registerFinal:



                String checked;
                if(peronel_patient.isChecked()){
                    checked = "personel";
                }
                else{
                    checked = "pacjent";
                }


               if(dm.CheckLogin(edit_login.getText().toString(),edit_password.getText().toString())){


                    dm.Register(edit_login.getText().toString(),edit_password.getText().toString(),edit_name.getText().toString(), edit_surname.getText().toString(),checked);



                   if(peronel_patient.isChecked()){
                        Intent switchActivityIntent = new Intent(this, PatientActivity.class);
                        startActivity(switchActivityIntent);
                    }
                    else{
                        Intent switchActivityIntent = new Intent(this, PersonelActivity.class);

                        startActivity(switchActivityIntent);
                    }

               }

                break;


        }
    }
}
