package com.example.inynieria;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import android.view.View;

import android.util.Log;
import android.database.Cursor;
import android.widget.Switch;

public class PersonelActivity extends AppCompatActivity implements  View.OnClickListener {



    public Button btnLista;
    public Button btnRecepty;
    public Button btnRozliczenia;
    public Button btnZasoby;
    public Button btnDodajZasoby;
    public Button btnSendKomunikat;
    public Button btnKomunikat;
    public TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personel);

        btnLista = (Button) findViewById(R.id.buttonLista);
        btnRecepty = (Button) findViewById(R.id.buttonWystawRecepty);
        btnRozliczenia= (Button) findViewById(R.id.buttonWystawRozliczenie);
        btnZasoby= (Button) findViewById(R.id.buttonZasoby);
        btnSendKomunikat = (Button) findViewById(R.id.buttonWyslijKomunikat);
        btnKomunikat= (Button) findViewById(R.id.buttonKomunikat);

        btnDodajZasoby = (Button) findViewById(R.id.buttonDodajZasoby);

        txt = (TextView)findViewById(R.id.textViewLOGGED2);
        txt.setText(people.login);
    }

    public void onClick(View v){
        switch(v.getId())
        {
            case R.id.buttonLista:
                Intent switchActivityIntent1 = new Intent(this, activityListaPacjentow.class);
                startActivity(switchActivityIntent1);
                break;

            case R.id.buttonWystawRecepty:
                Intent switchActivityIntent2 = new Intent(this, activityWystawRecepte.class);
                startActivity(switchActivityIntent2);
                break;


            case R.id.buttonWystawRozliczenie:
                Intent switchActivityIntent3 = new Intent(this, activityWystawRozliczenie.class);
                startActivity(switchActivityIntent3);
                break;



            case R.id.buttonZasoby:
                Intent switchActivityIntent4 = new Intent(this, activityZasoby.class);
                startActivity(switchActivityIntent4);
                break;



            case R.id.buttonWyslijKomunikat:
                Intent switchActivityIntent5 = new Intent(this, activityWystawKomunikat.class);
                startActivity(switchActivityIntent5);
                break;



            case R.id.buttonKomunikat:
                Intent switchActivityIntent6 = new Intent(this, activityKomunikat.class);
                startActivity(switchActivityIntent6);
                break;

            case R.id.buttonDodajZasoby:
                Intent switchActivityIntent7 = new Intent(this, ActivityDodajZasoby.class);
                startActivity(switchActivityIntent7);
                break;


            case R.id.buttonWylogujPersonel:


                people.personel_or_patient = null;
                people.name = null;
                people.surname = null;
                people.login = null;
                people.personId = null;

                Intent switchActivityIntent8 = new Intent(this, MainActivity.class);
                startActivity(switchActivityIntent8);
                break;

        }
    }
}