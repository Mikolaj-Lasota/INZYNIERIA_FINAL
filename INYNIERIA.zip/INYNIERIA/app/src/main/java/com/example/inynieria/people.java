package com.example.inynieria;

public class people {

    public static String personId;
    public static String login;
    public static String name;
    public static String surname;

    public static String personel_or_patient;

}
