package com.example.inynieria;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.database.Cursor;

public class ZarzadzajDanymi {

    private SQLiteDatabase db;

    public static final String TABLE_ROW_ID = "_id";
    public static final String TABLE_ROW_LOGIN = "login";
    public static final String TABLE_ROW_PASSWORD = "pasword";
    public static final String TABLE_ROW_IMIE = "imie";
    public static final String TABLE_ROW_NAZWISKO = "nazwisko";
    public static final String TABLE_ROW_PATIENT_OR_PERSONEL = "patient_or_personel";

    public static final String TABLE_C_AND_D = "doctors_and_choroby";
    public static final String DB_NAME = "address_logins";
    public static final int DB_VERSION = 1;
    public static final String TABLE_L_AND_P = "logins_and_passwords";



    public static final String TABLE_ROW_DOKTOR_IMIE = "doktor_imie";

    public static final String TABLE_ROW_DOKTOR_NAZWISKO = "doktor_nazwisko";
    public static final String TABLE_ROW_CHOROBA = "choroba";



    public static final String TABLE_ROW_LEK = "lek";
    public static final String TABLE_LEKI = "leki";


    public static final String TABLE_ROW_CENA = "cena";
    public static final String TABLE_ROZLICZENIA = "rozliczenia";


    public static final String TABLE_KOMUNIKATY = "komunikaty";

    public static final String TABLE_ROW_KOMUNIKAT = "komunikat";




    public static final String TABLE_INVENTORY = "inventory";

    public static final String TABLE_ROW_ZASOB = "zasob";



    public boolean logged = false;


    private class CustomSQLiteOpenHelper extends SQLiteOpenHelper {

        public CustomSQLiteOpenHelper(Context context){
            super(context,DB_NAME,null,DB_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db){

            String newTableQueryString1 = "create table "
                    + TABLE_L_AND_P + " ("
                    +TABLE_ROW_ID
                    +" integer primary key autoincrement not null,"
                    +TABLE_ROW_LOGIN
                    + " text not null, "
                    + TABLE_ROW_PASSWORD
                    + " text not null,"
                    +TABLE_ROW_IMIE
                    + " text not null, "
                    +TABLE_ROW_NAZWISKO
                    + " text not null, "
                    + TABLE_ROW_PATIENT_OR_PERSONEL
                    +" text not null);";
            db.execSQL(newTableQueryString1);


            String newTableQueryString2 = "create table "
                    + TABLE_C_AND_D + " ("
                    +TABLE_ROW_ID
                    +" integer primary key autoincrement not null,"
                    +TABLE_ROW_CHOROBA
                    + " text not null, "
                    + TABLE_ROW_DOKTOR_IMIE
                    + " text not null,"
                    + TABLE_ROW_DOKTOR_NAZWISKO
                    +" text not null);";
            db.execSQL(newTableQueryString2);



            String newTableQueryString3 = "create table "
                    + TABLE_LEKI + " ("
                    +TABLE_ROW_ID
                    +" integer primary key autoincrement not null,"
                    +TABLE_ROW_LEK
                    + " text not null, "
                    + TABLE_ROW_IMIE
                    + " text not null,"
                    + TABLE_ROW_NAZWISKO
                    +" text not null);";
            db.execSQL(newTableQueryString3);


            String newTableQueryString4 = "create table "
                    + TABLE_ROZLICZENIA + " ("
                    +TABLE_ROW_ID
                    +" integer primary key autoincrement not null,"
                    +TABLE_ROW_CENA
                    + " float not null, "
                    + TABLE_ROW_IMIE
                    + " text not null,"
                    + TABLE_ROW_NAZWISKO
                    +" text not null);";
            db.execSQL(newTableQueryString4);




            String newTableQueryString5 = "create table "
                    + TABLE_KOMUNIKATY + " ("
                    +TABLE_ROW_ID
                    +" integer primary key autoincrement not null,"
                    +TABLE_ROW_KOMUNIKAT
                    + " text not null, "
                    + TABLE_ROW_PATIENT_OR_PERSONEL
                    +" text not null);";
            db.execSQL(newTableQueryString5);



            String newTableQueryString6 = "create table "
                    + TABLE_INVENTORY + " ("
                    +TABLE_ROW_ID
                    +" integer primary key autoincrement not null,"
                    +TABLE_ROW_ZASOB
                    +" text not null);";
            db.execSQL(newTableQueryString6);


        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

        }
    }


    public ZarzadzajDanymi(Context context){
        CustomSQLiteOpenHelper helper = new CustomSQLiteOpenHelper(context);
        db = helper.getWritableDatabase();
    }


    public void InsertWizyta(String chorob, String docName, String docSurname){

        String query = "INSERT INTO " + TABLE_C_AND_D + " (" + TABLE_ROW_CHOROBA + ", " + TABLE_ROW_DOKTOR_IMIE +  ", " + TABLE_ROW_DOKTOR_NAZWISKO + ")"
                + "VALUES (" + "'" + chorob + "," + docName + ","+ docSurname + "');";

        Log.i("insert()", query);
        db.execSQL(query);

    }


    public void InsertRecepta(String medicine, String nazwa, String nazwisk){

        String query = "INSERT INTO " + TABLE_LEKI + " (" + TABLE_ROW_LEK + ", " + TABLE_ROW_IMIE +  ", " + TABLE_ROW_NAZWISKO + ")"
                + "VALUES (" + "'" + medicine + "," + nazwa + ","+ nazwisk + "');";


        Log.i("insert()", query);
        db.execSQL(query);

    }


    public void InsertRozliczenia(float price, String nazwa, String nazwisk){

        String query = "INSERT INTO " + TABLE_ROZLICZENIA + " (" + TABLE_ROW_CENA + ", " + TABLE_ROW_IMIE +  ", " + TABLE_ROW_NAZWISKO + ")"
                + "VALUES (" + "'" + price + "," + nazwa + ","+ nazwisk + "');";

        Log.i("insert()", query);
        db.execSQL(query);

    }


    public void InsertKomunikat(String text, String personel_patient){

        String query = "INSERT INTO " + TABLE_KOMUNIKATY + " (" + TABLE_ROW_KOMUNIKAT + ", " + TABLE_ROW_PATIENT_OR_PERSONEL + ")"
                + "VALUES (" + "'" + text + "," + personel_patient + "');";

        Log.i("insert()", query);
        db.execSQL(query);

    }

    public void InsertZasob(String zasob){
        String query = "INSERT INTO " + TABLE_INVENTORY + " (" + TABLE_ROW_ZASOB + ")"
                + "VALUES (" + "'" + zasob + "');";

        Log.i("insert()", query);
        db.execSQL(query);
    }




    //?!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    public void Register(String log, String pass, String im, String nazw, String personel_patient){

        String query = "INSERT INTO " + TABLE_L_AND_P + " (" + TABLE_ROW_LOGIN + ", " + TABLE_ROW_PASSWORD + ", " + TABLE_ROW_IMIE + ", " + TABLE_ROW_NAZWISKO + ", " + TABLE_ROW_PATIENT_OR_PERSONEL +")"
                + "VALUES (" + "'" + log + "," + pass + "," + im + "," + nazw + ","  + personel_patient + "');";

        Log.i("insert()", query);
        db.execSQL(query);

    }


    //?!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    public boolean CheckLogin(String log, String pass){
        String query = "SELECT " +  TABLE_ROW_ID + ", " + TABLE_ROW_LOGIN + ", " +TABLE_ROW_PASSWORD + ", " + TABLE_ROW_IMIE + ", " + TABLE_ROW_NAZWISKO + ", " + TABLE_ROW_PATIENT_OR_PERSONEL
                +" FROM" + TABLE_L_AND_P + " WHERE " + TABLE_ROW_LOGIN + " = '" + log + " AND " + TABLE_ROW_PASSWORD + " = '" + pass +  "';";

        db.execSQL(query);

        if(query == null)
        {
         return Login(log,pass,true);

        }
        else
        {
           return Login(log,pass, false);

        }



    }









    public Cursor showLoginPass(String login, String password){

        String query = "SELECT " +  TABLE_ROW_ID + ", " + TABLE_ROW_LOGIN + ", " +TABLE_ROW_PASSWORD + ", " + TABLE_ROW_IMIE + ", " + TABLE_ROW_NAZWISKO + ", " + TABLE_ROW_PATIENT_OR_PERSONEL
                +" FROM" + TABLE_L_AND_P + " WHERE " + TABLE_ROW_LOGIN + " = '" + login + " AND " +  TABLE_ROW_PASSWORD + " = " + password + "';";
        Log.i("searchName() =", query);
        Cursor c = db.rawQuery(query,null);
        return c;

    }


    public boolean Login(String log, String pass, boolean truth){

        Cursor c = showLoginPass(log,pass);

        while(c.moveToNext()){
            people.personId = c.getString(0);
            people.login = c.getString(1);
            people.name = c.getString(3);
            people.surname = c.getString(4);
            people.personel_or_patient = c.getString(5);
        }

        if(truth){return true;}
        else{ return false;}

    }



    public String showRecepty (String imie, String nazwisko){
        Cursor c = cursorRecepty(imie,nazwisko);

        String outer = "";

        while(c.moveToNext()){
            outer += "Lek: ";
            outer += c.getString(1);
            outer += " | Imię: ";
            outer += c.getString(2);
            outer += " | Nazwisko: ";
            outer += c.getString(3);
            outer += "\n";
        }

        return outer;

    }


    public Cursor cursorRecepty(String imie, String nazwisko ){

        String query = "SELECT " +  TABLE_ROW_ID + ", " + TABLE_ROW_LEK + ", " +TABLE_ROW_IMIE + ", " + TABLE_ROW_NAZWISKO
                +" FROM" + TABLE_LEKI + " WHERE " + TABLE_ROW_IMIE + " = '" + imie + " AND " +  TABLE_ROW_NAZWISKO + " = " + nazwisko +  "';";
        Log.i("searchName() =", query);
        Cursor c = db.rawQuery(query,null);
        return c;

    }







    public String showRozliczenia (String imie, String nazwisko){
        Cursor c = cursorRecepty(imie,nazwisko);

        String outer = "";

        while(c.moveToNext()){
            outer += "Cena: ";
            outer += c.getString(1);
            outer += " | Imię: ";
            outer += c.getString(2);
            outer += " | Nazwisko: ";
            outer += c.getString(3);
            outer += "\n";
        }

        return outer;

    }


    public Cursor cursorRozliczenia(String imie, String nazwisko ){

        String query = "SELECT " +  TABLE_ROW_ID + ", " + TABLE_ROW_CENA + ", " +TABLE_ROW_IMIE + ", " + TABLE_ROW_NAZWISKO
                +" FROM" + TABLE_ROZLICZENIA + " WHERE " + TABLE_ROW_IMIE + " = '" + imie + " AND " +  TABLE_ROW_NAZWISKO + " = " + nazwisko +  "';";
        Log.i("searchName() =", query);
        Cursor c = db.rawQuery(query,null);
        return c;

    }






    public String showLista (String Dokimie, String Doknazwisko){
        Cursor c = cursorRecepty(Dokimie,Doknazwisko);

        String outer = "";

        while(c.moveToNext()){
            outer += "Choroba: ";
            outer += c.getString(1);
            outer += " | Imię: ";
            outer += c.getString(2);
            outer += " | Nazwisko: ";
            outer += c.getString(3);
            outer += "\n";
        }

        return outer;

    }


    public Cursor cursorLista(String imie, String nazwisko ){

        String query = "SELECT " +  TABLE_ROW_ID + ", " + TABLE_ROW_CHOROBA + ", " +TABLE_ROW_DOKTOR_IMIE + ", " + TABLE_ROW_DOKTOR_NAZWISKO
                +" FROM" + TABLE_C_AND_D + " WHERE " + TABLE_ROW_DOKTOR_IMIE + " = '" + imie + " AND " +  TABLE_ROW_DOKTOR_NAZWISKO + " = " + nazwisko + "';";
        Log.i("searchName() =", query);
        Cursor c = db.rawQuery(query,null);
        return c;

    }






    public String showKomunikat (String person_or_patient){
        Cursor c = cursorKomunikat(person_or_patient);

        String outer = "";

        while(c.moveToNext()){
            outer += "Komunikat: ";
            outer += c.getString(1);
            outer += "\n";
        }

        return outer;

    }


    public Cursor cursorKomunikat(String person_or_patient){

        String query = "SELECT " +  TABLE_ROW_ID + ", " + TABLE_ROW_KOMUNIKAT + ", " + TABLE_ROW_PATIENT_OR_PERSONEL
                +" FROM" + TABLE_KOMUNIKATY + " WHERE " + TABLE_ROW_PATIENT_OR_PERSONEL + " = '" + person_or_patient + "" + "';";
        Log.i("searchName() =", query);
        Cursor c = db.rawQuery(query,null);
        return c;

    }






    public String showZasob (){

        Cursor c = db.rawQuery("SELECT * from " + TABLE_ROW_ZASOB,null);;

        String outer = "";

        while(c.moveToNext()){
            outer += "Komunikat: ";
            outer += c.getString(1);
            outer += "\n";
        }

        return outer;

    }







    /*?!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    public boolean Login(String log, String pass){
        String query = "SELECT " +  TABLE_ROW_ID + ", " + TABLE_ROW_LOGIN + ", " +TABLE_ROW_PASSWORD + ", " + TABLE_ROW_PATIENT_OR_PERSONEL
                +" FROM" + TABLE_L_AND_P + " WHERE " + TABLE_ROW_LOGIN + " = '" + log + " AND " + TABLE_ROW_PASSWORD + " = '" + pass +  "';";

        db.execSQL(query);
        if(query == null) {}
        else{ logged = true;}

        if(TABLE_ROW_PATIENT_OR_PERSONEL == "true"){
            return true;
        }else{
            return false;
        }
    }*/



  /*  public void delete(String name){
            String query = "DELETE FROM" + TABLE_N_AND_S
                    +" WHERE" + TABLE_ROW_NAME +
                    " = '" + name + "';";
            Log.i("delete() =", query);
            db.execSQL(query);

    }*/

    public Cursor SelectAll(){
        Cursor c = db.rawQuery("SELECT * from " + TABLE_L_AND_P,null);
        return c;
    }






}
